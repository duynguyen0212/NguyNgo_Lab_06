package Lab_06;
import java.util.ArrayList;
import java.util.Iterator;


public class GenOrchestra<T> implements Iterable<T>{
        ArrayList<Instruments> instrumentsList = new ArrayList<>();
        int currentIndex = 0;

        public void addInstruments(Instruments instrument){
            instrumentsList.add(instrument);
            currentIndex++;
        }

        @Override
        public Iterator<T> iterator() {
            Iterator<T> it = new Iterator<T>()
            {
                int currentIndexIterator = 0;

                @Override
                public boolean hasNext() {
                    return currentIndexIterator < currentIndex;
                }

                @Override
                public T next() {
                    return (T) instrumentsList.get(currentIndexIterator++);
                }

            };
            return it;
        }

        public void playAll(GenOrchestra genOrchestra){
            Iterator<Instruments> iterator = genOrchestra.iterator();
            while(iterator.hasNext())
            {
                iterator.next().play();
            }
        }

        public void tuneAll(char note, GenOrchestra genOrchestra){
            Iterator<Instruments> iterator = genOrchestra.iterator();
            while(iterator.hasNext())
            {
                iterator.next().tune(note);
            }
        }
}



