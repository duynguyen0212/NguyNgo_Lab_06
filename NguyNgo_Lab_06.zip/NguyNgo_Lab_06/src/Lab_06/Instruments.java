package Lab_06;

interface Instruments {
    public void play();
    public void tune(char note);
}



